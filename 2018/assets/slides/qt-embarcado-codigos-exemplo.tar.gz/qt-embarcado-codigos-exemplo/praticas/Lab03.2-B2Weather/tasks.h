#ifndef TASKS_H
#define TASKS_H

#include <QObject>

class Tasks : public QObject
{
    Q_OBJECT
public:
    explicit Tasks(QObject *parent = nullptr);

    Q_INVOKABLE bool detectTouchScreen() const;
    Q_INVOKABLE bool detectIpeBoard() const;
    Q_INVOKABLE void displayOff();
    Q_INVOKABLE void displayOn();
    Q_INVOKABLE void displayBrightness(const int b);

    bool readDmesg(void);

    // Variables Static used in QCommandLineParser
    static bool modeEmulator;

private:
    bool m_devTouch;
    bool m_ipeBoard;

signals:

public slots:
};

#endif // TASKS_H
