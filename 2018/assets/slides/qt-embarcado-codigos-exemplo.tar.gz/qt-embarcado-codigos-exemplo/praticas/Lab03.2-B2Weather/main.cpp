#include <QCommandLineParser>
#include <QDateTime>
#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QScreen>
#include <QTimer>
#include "tasks.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    qDebug() << "PID: " << QCoreApplication::applicationPid();
    QCoreApplication::setApplicationName("B2Weather - B2Open Systems and QtCon2018");
    QCoreApplication::setApplicationVersion("1.0");

    QGuiApplication app(argc, argv);

    QCommandLineParser parser;
    parser.setApplicationDescription("B2Weather Helper");
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addOptions({
                          {
                              "emulator-embedded",
                              QCoreApplication::translate("main", "Mode without Hardware Embedded")
                          }
                      });
    // Process the actual command line arguments given by the user
    parser.process(app);


    Tasks::modeEmulator = parser.isSet("emulator-embedded");


    qmlRegisterType<Tasks>("b2open.qt", 1, 0, "Tasks");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}

