#include "tasks.h"
#include <QDebug>
#include <QFile>
#include <QProcess>
#include <QTextStream>

// Initialize Static Variables
bool Tasks::modeEmulator(false);


Tasks::Tasks(QObject *parent) :
    QObject(parent),
    m_devTouch(false),
    m_ipeBoard(false)
{
    readDmesg();

    qDebug() << "Modo Emulador: " << Tasks::modeEmulator;
}

bool Tasks::detectTouchScreen() const
{
    return m_devTouch;
}

bool Tasks::detectIpeBoard() const
{
    return m_ipeBoard;
}

void Tasks::displayOff()
{
    QFile pathBacklightPower("/sys/class/backlight/backlight/bl_power");
    if(pathBacklightPower.exists() && pathBacklightPower.open(QIODevice::WriteOnly | QIODevice::Text)) {
        pathBacklightPower.write("4");
        pathBacklightPower.close();
    } else {
        qCritical() << "Falha ao tentar abrir " << pathBacklightPower.fileName();
    }
}

void Tasks::displayOn()
{
    QFile pathBacklightPower("/sys/class/backlight/backlight/bl_power");
    if(pathBacklightPower.exists() && pathBacklightPower.open(QIODevice::WriteOnly | QIODevice::Text)) {
        pathBacklightPower.write("0");
        pathBacklightPower.close();
    } else {
        qCritical() << "Falha ao tentar abrir " << pathBacklightPower.fileName();
    }
}

void Tasks::displayBrightness(const int b)
{
    QFile pathBacklightBrightness("/sys/class/backlight/backlight/brightness");
    if(pathBacklightBrightness.exists() && pathBacklightBrightness.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (b >= 0 && b <= 7) {
            pathBacklightBrightness.write(QByteArray::number(b));
        } else {
            pathBacklightBrightness.write("6");
        }
        pathBacklightBrightness.close();
    } else {
        qCritical() << "Falha ao tentar abrir " << pathBacklightBrightness.fileName();
    }
}

bool Tasks::readDmesg()
{
    if (Tasks::modeEmulator) {
        m_devTouch = true;
        m_ipeBoard = true;
        return true;
    }

    QProcess cmdDmesg;
    cmdDmesg.start("/bin/dmesg", QIODevice::ReadOnly);
    if (!cmdDmesg.waitForFinished()) {
        return false;
    }

    QTextStream out(cmdDmesg.readAll());
    QString s;
    cmdDmesg.close();

    while (!(s = out.readLine()).isNull()) {
        if (!m_devTouch) {
            if (s.contains(QRegExp(QStringLiteral("stmpe-i2c.*detected")))) {
                m_devTouch = true;
            }
        }
        if (!m_ipeBoard) {
            if (s.contains(QRegExp(QStringLiteral("mma8452.*accelerometer")))) {
                m_ipeBoard = true;
            }
        }
    }

    qDebug() << "TouchScreen  : " << m_devTouch;
    qDebug() << "IPE Board    : " << m_ipeBoard;

    return true;

}
