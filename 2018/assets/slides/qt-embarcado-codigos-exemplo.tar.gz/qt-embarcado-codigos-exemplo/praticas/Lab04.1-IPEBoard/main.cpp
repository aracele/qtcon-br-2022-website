#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "acelerometro.h"
#include "buzzer.h"
#include "led.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    qmlRegisterType<Toradex::Acelerometro>("b2open.qt", 1, 0, "Acelerometro");
    qmlRegisterType<Toradex::Buzzer>("b2open.qt", 1, 0, "Buzzer");
    qmlRegisterType<Toradex::Led>("b2open.qt", 1, 0, "Led");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
