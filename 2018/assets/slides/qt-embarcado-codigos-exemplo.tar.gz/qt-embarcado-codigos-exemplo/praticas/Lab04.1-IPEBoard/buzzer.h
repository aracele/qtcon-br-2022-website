#ifndef BUZZER_H
#define BUZZER_H

#include <QObject>

/*
 * Referencia: https://developer.toradex.com/knowledge-base/pwm-(linux)
 */
namespace Toradex {

class Buzzer : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int pwm         WRITE setPwm       NOTIFY changedPwm)
    Q_PROPERTY(int period      WRITE setPeriod    NOTIFY changedPeriod)
    Q_PROPERTY(int dutycycle   WRITE setDutyCycle NOTIFY changedDutyCycle)
    Q_PROPERTY(bool run  READ run WRITE setRun       NOTIFY changedRun)

    Q_ENUMS(PWM)

public:
    enum PWM  { PWM_A=255, PWM_B=0, PWM_C=3, PWM_D=1 };

    explicit Buzzer(QObject *parent = nullptr);
    ~Buzzer();

    void setPwm(const int pwm);
    void setPeriod(const int period);
    void setDutyCycle(const int dutycycle);
    void setRun(bool flag);
    bool run() const;


private:
    int m_pwm;
    int m_period;
    int m_dutyCycle;
    bool m_run;

signals:
    void changedPwm();
    void changedPeriod();
    void changedDutyCycle();
    void changedRun();


public slots:

};

}
#endif // BUZZER_H
