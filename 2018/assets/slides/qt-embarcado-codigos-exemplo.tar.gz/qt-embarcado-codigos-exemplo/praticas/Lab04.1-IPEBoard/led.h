#ifndef LED_H
#define LED_H

#include <QObject>

namespace Toradex {

class Led : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int led                WRITE setLed   NOTIFY changedLed)
    Q_PROPERTY(int modo               WRITE setModo  NOTIFY changedModo)
    Q_PROPERTY(bool ligar  READ ligar WRITE setLigar NOTIFY changedLigar)

    Q_ENUMS(Modos)
    Q_ENUMS(Leds)

public:
    enum Leds  { Led101=1, Led103=2, Led133=3 };
    enum Modos { None, Timer, OneShot, HeartBeat, BackLight, Gpio, DefaultOn };

    explicit Led(QObject *parent = nullptr);
    ~Led();

    void setLed(const int led);
    void setModo(const int modo);
    void setLigar(bool flag);
    bool ligar() const;

    Q_INVOKABLE void on();
    Q_INVOKABLE void off();

private:
    int m_led;
    int m_modo;
    bool m_ligar;


signals:
    void changedLed();
    void changedModo();
    void changedLigar();


public slots:
};

}

#endif // LED_H
