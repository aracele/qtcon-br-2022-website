#include "buzzer.h"
#include <QDebug>
#include <QFile>
#include <QString>

const qint16 value_default{-1};

Toradex::Buzzer::Buzzer(QObject *parent) :
    QObject(parent),
    m_pwm(value_default),
    m_period(value_default),
    m_dutyCycle(value_default),
    m_run(false)

{

}

Toradex::Buzzer::~Buzzer()
{
    qDebug() << Q_FUNC_INFO;
    setRun(false);
}

void Toradex::Buzzer::setPwm(const int pwm)
{
    qDebug() << "Configurando PWM: " << pwm;
    if (m_pwm != pwm) {
        m_pwm = pwm;
    }

    Q_EMIT changedPwm();
}

void Toradex::Buzzer::setPeriod(const int period)
{
    qDebug() << "Configurando Periodo: " << period;
    if (m_period != period) {
        m_period = period*1000000;        // ms -> ns
    }

    Q_EMIT changedPeriod();
}

void Toradex::Buzzer::setDutyCycle(const int dutycycle)
{
    qDebug() << "Configurando DutyCycle: " << dutycycle;
    if (m_dutyCycle != dutycycle) {
        m_dutyCycle = dutycycle*1000000;  // ms -> ns
    }

    Q_EMIT changedDutyCycle();
}

void Toradex::Buzzer::setRun(bool flag)
{
    // Verifica se foi passado True ou False para execucao
    if (flag) {
        // Confirma que todos opções foram configuradas
        if (m_pwm != value_default && m_period != value_default && m_dutyCycle != value_default) {
            QFile pathPwm(QString("/sys/class/pwm/pwmchip%1/export").arg(m_pwm));
            if (pathPwm.exists() && pathPwm.open(QIODevice::WriteOnly | QIODevice::Text)) {
                // Exportando para criar pwmchip%1/pwm0
                pathPwm.write("0"); //PWM0
                pathPwm.close();

                // Configurando Periodo
                QFile pathPwmPeriod(QString("/sys/class/pwm/pwmchip%1/pwm0/period").arg(m_pwm));
                if (pathPwmPeriod.exists() && pathPwmPeriod.open(QIODevice::WriteOnly | QIODevice::Text)) {
                    //qDebug() << "Configurando Periodo   : " << QByteArray::number(m_period);
                    pathPwmPeriod.write(QByteArray::number(m_period));
                    pathPwmPeriod.close();
                } else {
                    qCritical() << "Falha ao tentar abrir " << pathPwmPeriod.fileName();
                }

                // Configurando Duty Cycle
                QFile pathPwmDutyCycle(QString("/sys/class/pwm/pwmchip%1/pwm0/duty_cycle").arg(m_pwm));
                if (pathPwmDutyCycle.exists() && pathPwmDutyCycle.open(QIODevice::WriteOnly | QIODevice::Text)) {
                    //qDebug() << "Configurando DutyCycle   : " << QByteArray::number(m_dutyCycle);
                    pathPwmDutyCycle.write(QByteArray::number(m_dutyCycle));
                    pathPwmDutyCycle.close();
                } else {
                    qCritical() << "Falha ao tentar abrir " << pathPwmDutyCycle.fileName();
                }

                // Habilitando PWM Buzzer
                QFile pathPwmEnable(QString("/sys/class/pwm/pwmchip%1/pwm0/enable").arg(m_pwm));
                if (pathPwmEnable.exists() && pathPwmEnable.open(QIODevice::WriteOnly | QIODevice::Text)) {
                    qDebug() << "Habilitando PWM";
                    pathPwmEnable.write("1");
                    pathPwmEnable.close();
                } else {
                    qCritical() << "Falha ao tentar abrir " << pathPwmEnable.fileName();
                }

            }
            else {
                qCritical() << "Falha ao tentar abrir " << pathPwm.fileName();
                return;
            }

        } else {
            qWarning() << "Falha ao iniciar Buzzer, verifique se configurou os atributos: pwm, period e dutycycle";
            return;
        }
    } else {
        // Desabilitando PWM Buzzer
        QFile pathPwmEnable(QString("/sys/class/pwm/pwmchip%1/pwm0/enable").arg(m_pwm));
        if (pathPwmEnable.exists() && pathPwmEnable.open(QIODevice::WriteOnly | QIODevice::Text)) {
            qDebug() << "Desabilitando PWM";
            pathPwmEnable.write("0");
            pathPwmEnable.close();
        } else {
            qCritical() << "Falha ao tentar abrir " << pathPwmEnable.fileName() << " para desabilitar";
        }

        // Unexport pwm0
        QFile pathPwm(QString("/sys/class/pwm/pwmchip%1/unexport").arg(m_pwm));
        if (pathPwm.exists() && pathPwm.open(QIODevice::WriteOnly | QIODevice::Text)) {
            // Exportando para criar pwmchip%1/pwm0
            pathPwm.write("0"); //PWM0
            pathPwm.close();
        } else {
            qCritical() << "Falha ao tentar abrir " << pathPwmEnable.fileName() << " para desabilitar pwm0";
        }
    }
}

bool Toradex::Buzzer::run() const
{
    return m_run;
}
