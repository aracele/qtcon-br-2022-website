#ifndef ACELEROMETRO_H
#define ACELEROMETRO_H

#include <QObject>
#include <QTimer>

namespace Toradex {

class Acelerometro : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int eixoX READ eixoX WRITE setEixoX NOTIFY changedEixoX)
    Q_PROPERTY(int eixoY READ eixoY WRITE setEixoY NOTIFY changedEixoY)
    Q_PROPERTY(int eixoZ READ eixoZ WRITE setEixoZ NOTIFY changedEixoZ)


public:
    explicit Acelerometro(QObject *parent = nullptr);
    ~Acelerometro();

    void setEixoX(const int value);
    int eixoX() const;
    void setEixoY(const int value);
    int eixoY() const;
    void setEixoZ(const int value);
    int eixoZ() const;

private:
    QString m_path_accel_x;
    QString m_path_accel_y;
    QString m_path_accel_z;

    int m_value_accel_x;
    int m_value_accel_y;
    int m_value_accel_z;

    QTimer timerAccel;


signals:
    void changedEixoX();
    void changedEixoY();
    void changedEixoZ();


public slots:

};
}
#endif // ACELEROMETRO_H
