#include "led.h"
#include <QDebug>
#include <QFile>

const qint16 value_default{-1};

Toradex::Led::Led(QObject *parent) :
    QObject(parent),
    m_led(value_default),
    m_modo(value_default),
    m_ligar(false)
{

}

Toradex::Led::~Led()
{
    qDebug() << Q_FUNC_INFO;
    setLigar(false);
}

void Toradex::Led::setLed(const int led)
{
    m_led = led;
    Q_EMIT changedLed();
}

void Toradex::Led::setModo(const int modo)
{
    m_modo = modo;
    Q_EMIT changedModo();
}

void Toradex::Led::setLigar(bool flag)
{
    m_ligar = flag;

    // Primeiro verifico se o 'led' foi configurado e o 'modo' com alguma opçao entre os Modos
    if (m_led == value_default) {
        qDebug() << "Led nao configurado, configure no atributo led: no QML";
        return;
    } else if (m_modo == value_default) {
        qDebug() << "Modo do led nao configurado, configure no atributo modo: no QML";
        return;
    }

    // Abre o caminho do Led especificado, verifica se conseguiu abrir com sucesso se sim, baseado no
    // modo especificado ira configurar o Led
    QFile pathLedTrigger(QString("/sys/class/leds/ipe:green:usr%1/trigger").arg(m_led));
    if(!pathLedTrigger.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qCritical() << "Falha ao abrir " << pathLedTrigger.fileName();
        return;
    }
    else {
        //qDebug() << "Sucesso: " << pathLedTrigger.fileName();

        // Caso recebeu um False, muda o Trigger para None, se True configura o modo para o led
        if (!flag) {
            //qDebug() << "Desligando Led";
            pathLedTrigger.write("none");
        }
        else {
            //qDebug() << "Ligando Led";
            switch (m_modo) {
            case Led::Modos::BackLight:
            {
                pathLedTrigger.write("backlight");
                break;
            }
            case Led::Modos::DefaultOn:
            {
                pathLedTrigger.write("default-on");
                break;
            }
            case Led::Modos::Gpio:
            {
                pathLedTrigger.write("gpio");
                on();
                break;
            }
            case Led::Modos::HeartBeat:
            {
                pathLedTrigger.write("heartbeat");
                break;
            }
            case Led::Modos::OneShot:
            {
                pathLedTrigger.write("oneshot");
                break;
            }
            case Led::Modos::Timer:
            {
                pathLedTrigger.write("timer");
                break;
            }
            }
        }

        pathLedTrigger.close();
    }
}

bool Toradex::Led::ligar() const
{
    return m_ligar;
}

void Toradex::Led::on()
{
    if (m_led == value_default) {
        qDebug() << "Led não configurado, configure no atributo led:";
        return;
    } else {
        QFile pathLedBrightness(QString("/sys/class/leds/ipe:green:usr%1/brightness").arg(m_led));
        if(!pathLedBrightness.open(QIODevice::WriteOnly | QIODevice::Text)) {
            qCritical() << "Falha ao abrir " << pathLedBrightness.fileName();
            return;
        }
        pathLedBrightness.write("128");
        pathLedBrightness.close();
    }
}

void Toradex::Led::off()
{
    if (m_led == value_default) {
        qDebug() << "Led não configurado, configure no atributo led:";
        return;
    } else {
        QFile pathLedBrightness(QString("/sys/class/leds/ipe:green:usr%1/brightness").arg(m_led));
        if(!pathLedBrightness.open(QIODevice::WriteOnly)) {
            qCritical() << "Falha ao abrir " << pathLedBrightness.fileName();
            return;
        }
        pathLedBrightness.write("0");
        pathLedBrightness.close();
    }
}
