#include "acelerometro.h"
#include <QDebug>
#include <QFile>
#include <QFileSystemWatcher>
#include <QTextStream>
#include <QTimer>

Toradex::Acelerometro::Acelerometro(QObject *parent) :
    QObject(parent),
    m_path_accel_x("/sys/bus/iio/devices/iio:device1/in_accel_x_raw"),
    m_path_accel_y("/sys/bus/iio/devices/iio:device1/in_accel_y_raw"),
    m_path_accel_z("/sys/bus/iio/devices/iio:device1/in_accel_z_raw"),
    m_value_accel_x(0),
    m_value_accel_y(0),
    m_value_accel_z(0)
{
    qDebug() << Q_FUNC_INFO;

    timerAccel.start(250);
    connect(&timerAccel, &QTimer::timeout, [&](){

        QByteArray rawAccelX;
        QFile fnAccelX(m_path_accel_x);
        QByteArray rawAccelY;
        QFile fnAccelY(m_path_accel_y);
        QByteArray rawAccelZ;
        QFile fnAccelZ(m_path_accel_z);

        if (fnAccelX.open(QIODevice::ReadOnly)) {         // Abre arquivo
            rawAccelX = fnAccelX.readAll().simplified();  // Le o arquivo e remove tabulacoes
            fnAccelX.close();                             // Fecha arquivo

            this->setEixoX(rawAccelX.toInt());            // Enviar para a funcao SetEixoX o valor
        }
        if (fnAccelY.open(QIODevice::ReadOnly)) {
            rawAccelY = fnAccelY.readAll().simplified();
            fnAccelY.close();

            this->setEixoY(rawAccelY.toInt());
        }
        if (fnAccelZ.open(QIODevice::ReadOnly)) {
            rawAccelZ = fnAccelZ.readAll().simplified();
            fnAccelZ.close();

            this->setEixoZ(rawAccelZ.toInt());
        }

    });

}

Toradex::Acelerometro::~Acelerometro()
{
    timerAccel.stop();
    qDebug() << Q_FUNC_INFO;
}

void Toradex::Acelerometro::setEixoX(const int value)
{
    //qDebug() << Q_FUNC_INFO << " : " << value;
    if(m_value_accel_x != value) {
        m_value_accel_x = value;

        Q_EMIT changedEixoX();
    }
}

int Toradex::Acelerometro::eixoX() const
{
    return m_value_accel_x;
}

void Toradex::Acelerometro::setEixoY(const int value)
{
    //qDebug() << Q_FUNC_INFO << " : " << value;
    if(m_value_accel_y != value) {
        m_value_accel_y = value;

        Q_EMIT changedEixoY();
    }
}

int Toradex::Acelerometro::eixoY() const
{
    return m_value_accel_y;
}

void Toradex::Acelerometro::setEixoZ(const int value)
{
    //qDebug() << Q_FUNC_INFO << " : " << value;
    if(m_value_accel_z != value) {
        m_value_accel_z = value;

        Q_EMIT changedEixoZ();
    }
}

int Toradex::Acelerometro::eixoZ() const
{
    return m_value_accel_z;
}
