#include "commands.h"
#include <QDebug>
#include <QProcess>

Toradex::Commands::Commands(QObject *parent) : QObject(parent)
{

}

void Toradex::Commands::powerOff()
{
    qDebug() << Q_FUNC_INFO;

#ifdef Q_PROCESSOR_ARM
    QProcess::startDetached("poweroff");
#endif

#ifdef Q_PROCESSOR_X86
    qInfo() << "Recurso não suportado ou desabilitado";
#endif

}
