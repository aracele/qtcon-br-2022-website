#ifndef COMMANDS_H
#define COMMANDS_H

#include <QObject>

namespace Toradex {
class Commands : public QObject
{
    Q_OBJECT
public:
    explicit Commands(QObject *parent = nullptr);

    Q_INVOKABLE void powerOff();

signals:

public slots:
};

}

#endif // COMMANDS_H
