#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <signal.h>
#include <unistd.h>
#include "acelerometro.h"
#include "buzzer.h"
#include "commands.h"
#include "led.h"

static void procUnixSignal(int sig)
{
    qDebug() << Q_FUNC_INFO << "Sinal recebido: " << sig;
    QCoreApplication::quit();
}

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    // Dicas e Truques - Processar Sinais Unix para encerrar a aplicação "corretamente"
    // Mais sinais, abra o terminal e digite: kill -l
    signal(SIGINT, procUnixSignal);    // Ctrl+C - Interrupção do Terminal
    signal(SIGQUIT, procUnixSignal);   // Quit vindo do Terminal
    signal(SIGTERM, procUnixSignal);   // Encerrar a aplicação
    signal(SIGHUP, procUnixSignal);    // Desconexão do Terminal

    qmlRegisterType<Toradex::Acelerometro>("b2open.qt", 1, 0, "Acelerometro");
    qmlRegisterType<Toradex::Buzzer>("b2open.qt", 1, 0, "Buzzer");
    qmlRegisterType<Toradex::Commands>("b2open.qt", 1, 0, "Commands");
    qmlRegisterType<Toradex::Led>("b2open.qt", 1, 0, "Led");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
